import psycopg2
con=psycopg2.connect(
     host="localhost",
     database="postgres",
     user="postgres",
    password="mm123456"
 )
cur=con.cursor()
cur.execute("CREATE TABLE customer(c_id text NOT NULL PRIMARY KEY,name text NOT NULL,family text NOT NULL,address text NOT NULL)")
cur.execute("CREATE TABLE products(name text NOT NULL PRIMARY KEY,count int,price NUMERIC(5,2))")
cur.execute("CREATE TABLE finished(title text)")
cur.execute("CREATE TABLE fish(purchase_id serial,c_id text,total_price numeric(5,2),orders text,status int,transmit_id int)")
cur.execute("CREATE TABLE transmitter(transmit_id int,name text,family text,salary numeric(5,2))")
cur.execute("CREATE TABLE discount(c_id text)")
cur.execute("insert into products values('water',4,12.2)")
cur.execute("insert into products values('bread',8,8)")
cur.execute("insert into products values('milk',6,5)")
cur.execute("insert into products values('eggs',4,2)")
cur.execute("insert into products values('apple',12,2)")
cur.execute("insert into products values('toast',10,10)")
cur.execute("insert into transmitter values(1,'hamed','sadr','10')")
cur.execute("insert into transmitter values(2,'hamid','ahmadi','10')")
cur.execute("insert into transmitter values(3,'ali','khajavi','10')")
cur.execute("insert into transmitter values(4,'kamran','ilami','10')")
con.commit()

